package com.example.datastructurevisualisationapp.StackClasses;

/**Class which represents an element in a stack.**/
public class StackElement {
    private String contents;

    /**Method which initialises StackElement with contents.**/
    public StackElement(String contents){
        this.contents = contents;
    }
}
