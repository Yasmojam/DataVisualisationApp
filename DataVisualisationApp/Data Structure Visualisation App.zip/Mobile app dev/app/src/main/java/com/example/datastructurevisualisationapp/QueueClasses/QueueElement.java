package com.example.datastructurevisualisationapp.QueueClasses;

/**Class which represents an element in a queue.**/
public class QueueElement {
    private String contents;

    /**Method which initialises QueueElement with contents.**/
    public QueueElement(String contents){
        this.contents = contents;
    }
}
